import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, Alert, Keyboard } from 'react-native';

export default function TaskListApp() {
  const [tasks, setTasks] = useState([]);
  const [taskText, setTaskText] = useState('');
  const [error, setError] = useState('');

  const addTask = () => {
    const trimmedText = taskText.trim();
    if (trimmedText === '') {
      setError('task cannot be empty');
      return;
    }
    setError('');
    
    const newTask = {
      id: Date.now().toString(),
      text: trimmedText,
      done: false
    };
    
    setTasks([...tasks, newTask]);
    setTaskText('');
    Keyboard.dismiss();
  };

  const toggleTask = (id) => {
    const updatedTasks = tasks.map(task => {
      if (task.id === id) {
        return { ...task, done: !task.done };
      }
      return task;
    });
    setTasks(updatedTasks);
  };


  const deleteTask = (id) => {
    const filteredTasks = tasks.filter(task => task.id !== id);
    setTasks(filteredTasks);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>My Task List</Text>
      
      <View style={styles.inputContainer}>
        <TextInput
          style={[styles.input, error ? styles.inputError : null]}
          placeholder="Enter a new task"
          value={taskText}
          onChangeText={(text) => {
            setTaskText(text);

            if (error) setError('');
          }}
          onSubmitEditing={addTask}
        />

        <TouchableOpacity style={styles.addButton} onPress={addTask}>
          <Text style={styles.addButtonText}>Add</Text>
        </TouchableOpacity>
      </View>
      

      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      
      <ScrollView style={styles.taskList}>
        {tasks.length === 0 ? (
          <Text style={styles.emptyText}>No tasks added yet</Text>
        ) : (
          tasks.map(task => (
            <View key={task.id} style={styles.taskItem}>
              
              <TouchableOpacity 
                onPress={() => toggleTask(task.id)}
                style={styles.taskContent}
              >
                <Text style={[
                  styles.taskText, 
                  task.done && styles.completedTask
                ]}>
                  {task.text}
                </Text>
              </TouchableOpacity>
              
              <View style={styles.taskActions}>
                <TouchableOpacity 
                  onPress={() => toggleTask(task.id)}
                  style={[styles.actionButton, task.done ? styles.undoButton : styles.doneButton]}
                >
                  <Text style={styles.actionText}>
                    {task.done ? 'Undo' : 'Done'}
                  </Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  onPress={() => deleteTask(task.id)}
                  style={[styles.actionButton, styles.deleteButton]}
                >
                  <Text style={styles.actionText}>Delete</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))
        )}
      </ScrollView>
      
      
      {tasks.length > 0 && (
        <View style={styles.footer}>
          <Text style={styles.counterText}>
            {tasks.filter(t => t.done).length} of {tasks.length} tasks completed
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    paddingTop: 50,
    backgroundColor: '#f0f8ff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#2c3e50',
  },
  inputContainer: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    padding: 10,
    backgroundColor: 'white',
    marginRight: 10,
  },
  inputError: {
    borderColor: 'red',
    borderWidth: 2,
  },
  addButton: {
    backgroundColor: 'blue',
    borderRadius: 5,
    justifyContent: 'center',
    paddingHorizontal: 15,
  },
  addButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  errorText: {
    color: 'red',
    marginBottom: 10,
    textAlign: 'center',
  },
  taskList: {
    flex: 1,
    marginBottom: 10,
  },
  taskItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 5,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    shadowColor: 'black',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 1,
    elevation: 1,
  },
  taskContent: {
    flex: 1,
  },
  taskText: {
    fontSize: 16,
  },
  completedTask: {
    textDecorationLine: 'line-through',
    color: 'grey',
  },
  taskActions: {
    flexDirection: 'row',
  },
  actionButton: {
    padding: 8,
    borderRadius: 4,
    marginLeft: 5,
  },
  doneButton: {
    backgroundColor: 'green',
  },
  undoButton: {
    backgroundColor: 'orange',
  },
  deleteButton: {
    backgroundColor: 'red',
  },
  actionText: {
    fontSize: 12,
    color: 'white',
    fontWeight: 'bold',
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 20,
    color: 'grey',
    fontSize: 16,
  },
  footer: {
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: 'grey',
    backgroundColor: 'white',
    borderRadius: 5,
  },
  counterText: {
    textAlign: 'center',
    color: 'grey',
  },
});