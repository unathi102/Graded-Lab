import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyDr34FGuRwqS5hLEg5q7wxFHBd_CSBovSs",
  authDomain: "hotel-booking-app-d7e0b.firebaseapp.com",
  projectId: "hotel-booking-app-d7e0b",
  storageBucket: "hotel-booking-app-d7e0b.firebasestorage.app",
  messagingSenderId: "220678031047",
  appId: "1:220678031047:web:62281732fc026f91d660e2"
};


const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export default app;