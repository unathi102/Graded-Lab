import React, { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { AppProvider } from './components/appContext'; 
import AppNavigator from './components/appNavigator'; 
import { auth, db } from "./firebase";
import { onAuthStateChanged } from 'firebase/auth';
import { collection, getDocs } from 'firebase/firestore';

export default function App() {
  useEffect(() => {
    const testFirebase = async () => {
      try {
        console.log('Testing Firebase connection...');
        
        const unsubscribe = onAuthStateChanged(auth, (user) => {
          console.log('Auth state changed:', user ? 'User logged in' : 'No user');
        });
        
        const querySnapshot = await getDocs(collection(db, 'test'));
        console.log('Firestore connection successful');
        
        unsubscribe();
      } catch (error) {
        console.error('Firestore test failed', error);
        console.log('But Auth is working!');
      }
    };
    
    testFirebase();
  }, []);

  return (
    <AppProvider>
      <StatusBar style="auto" />
      <AppNavigator />
    </AppProvider>
  );
}