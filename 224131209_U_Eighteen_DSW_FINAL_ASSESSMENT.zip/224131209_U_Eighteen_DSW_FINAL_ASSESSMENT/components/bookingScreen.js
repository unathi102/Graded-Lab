import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput
} from 'react-native';
import { useApp } from './appContext';
import { doc, setDoc, collection, addDoc } from 'firebase/firestore';
import { db } from '../firebase';

const BookingScreen = ({ route, navigation }) => {
  const { hotel } = route.params;
  const { user, addBooking } = useApp();
  
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState('1');
  const [rooms, setRooms] = useState('1');
  const [loading, setLoading] = useState(false);

  const calculateTotal = () => {
    if (!checkIn || !checkOut) return 0;
    
    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);
    const nights = Math.ceil((checkOutDate - checkInDate) / (1000 * 60 * 60 * 24));
    
    if (nights <= 0) return 0;
    
    return nights * hotel.price * parseInt(rooms);
  };

  const validateDates = () => {
    if (!checkIn || !checkOut) {
      Alert.alert('Error', 'Please select both check-in and check-out dates');
      return false;
    }

    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (checkInDate < today) {
      Alert.alert('Error', 'Check-in date cannot be in the past');
      return false;
    }

    if (checkOutDate <= checkInDate) {
      Alert.alert('Error', 'Check-out date must be after check-in date');
      return false;
    }

    return true;
  };

  const handleBooking = async () => {
    if (!validateDates()) return;

    setLoading(true);
    try {
      const bookingData = {
        hotelId: hotel.id,
        hotelName: hotel.name,
        hotelImage: hotel.image,
        hotelLocation: hotel.location,
        checkIn: checkIn,
        checkOut: checkOut,
        guests: parseInt(guests),
        rooms: parseInt(rooms),
        totalPrice: calculateTotal(),
        userId: user.uid,
        userName: user.displayName,
        userEmail: user.email,
        bookingDate: new Date().toISOString(),
        status: 'confirmed'
      };

    
      const bookingRef = await addDoc(collection(db, 'bookings'), bookingData);
      

      addBooking({ ...bookingData, id: bookingRef.id });

      Alert.alert(
        'Booking Confirmed!',
        `Your booking at ${hotel.name} has been confirmed. Total: ${calculateTotal()}`,
        [
          {
            text: 'OK',
            onPress: () => navigation.navigate('BookingConfirmation', {
              booking: { ...bookingData, id: bookingRef.id }
            })
          }
        ]
      );
    } catch (error) {
      Alert.alert('Booking Failed', error.message);
    } finally {
      setLoading(false);
    }
  };

  const total = calculateTotal();
  const nights = total > 0 ? Math.ceil(total / hotel.price / parseInt(rooms)) : 0;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.hotelName}>{hotel.name}</Text>
        <Text style={styles.hotelLocation}>{hotel.location}</Text>
      </View>

      <View style={styles.bookingForm}>
        <Text style={styles.sectionTitle}>Booking Details</Text>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Check-in Date</Text>
          <TextInput
            style={styles.input}
            placeholder="YYYY-MM-DD"
            value={checkIn}
            onChangeText={setCheckIn}
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Check-out Date</Text>
          <TextInput
            style={styles.input}
            placeholder="YYYY-MM-DD"
            value={checkOut}
            onChangeText={setCheckOut}
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Number of Guests</Text>
          <TextInput
            style={styles.input}
            placeholder="1"
            value={guests}
            onChangeText={setGuests}
            keyboardType="numeric"
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Number of Rooms</Text>
          <TextInput
            style={styles.input}
            placeholder="1"
            value={rooms}
            onChangeText={setRooms}
            keyboardType="numeric"
          />
        </View>

        {total > 0 && (
          <View style={styles.priceBreakdown}>
            <Text style={styles.priceTitle}>Price Breakdown</Text>
            <View style={styles.priceRow}>
              <Text style={styles.priceLabel}>
                R{hotel.price} × {nights} nights × {rooms} rooms
              </Text>
              <Text style={styles.priceValue}>R{total}</Text>
            </View>
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Total</Text>
              <Text style={styles.totalValue}>R{total}</Text>
            </View>
          </View>
        )}

        <TouchableOpacity
          style={[styles.bookButton, loading && styles.bookButtonDisabled]}
          onPress={handleBooking}
          disabled={loading || total === 0}
        >
          <Text style={styles.bookButtonText}>
            {loading ? 'Processing...' : `Confirm Booking - R${total}`}
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e8e8e8',
  },
  hotelName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  hotelLocation: {
    fontSize: 16,
    color: '#666',
  },
  bookingForm: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#e8e8e8',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#f8f8f8',
  },
  priceBreakdown: {
    backgroundColor: '#f8f8f8',
    padding: 16,
    borderRadius: 8,
    marginBottom: 24,
  },
  priceTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#333',
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  priceLabel: {
    fontSize: 14,
    color: '#666',
  },
  priceValue: {
    fontSize: 14,
    color: '#666',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#e8e8e8',
    paddingTop: 8,
    marginTop: 8,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  totalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FF385C',
  },
  bookButton: {
    backgroundColor: '#FF385C',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  bookButtonDisabled: {
    opacity: 0.6,
  },
  bookButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default BookingScreen;