import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  TextInput,
  Alert
} from 'react-native';
import { useApp } from './appContext';

const ExploreScreen = ({ navigation }) => {
  const { user } = useApp();
  const [hotels, setHotels] = useState([]);
  const [filteredHotels, setFilteredHotels] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('name');

  
  const sampleHotels = [
    {
      id: '1',
      name: 'Luxury Resort & Spa',
      location: 'Bali, Indonesia',
      rating: 4.8,
      price: 299,
      image: require('../assets/Materials/06-Explore Page/image-14.png'),
      description: 'A beautiful luxury resort with spa and private beach access.'
    },
    {
      id: '2',
      name: 'City View Hotel',
      location: 'New York, USA',
      rating: 4.5,
      price: 199,
      image: require('../assets/Materials/06-Explore Page/image-13.png'),
      description: 'Modern hotel in the heart of Manhattan with stunning city views.'
    },
    {
      id: '3',
      name: 'Mountain Retreat',
      location: 'Swiss Alps, Switzerland',
      rating: 4.9,
      price: 349,
      image: require('../assets/Materials/06-Explore Page/Rectangle 783.png'),
      description: 'Cozy retreat in the mountains with ski-in/ski-out access.'
    },
    {
      id: '4',
      name: 'Beachfront Paradise',
      location: 'Maldives',
      rating: 4.7,
      price: 499,
      image: require('../assets/Materials/06-Explore Page/Rectangle 784.png'),
      description: 'Overwater bungalows with direct access to crystal clear waters.'
    },
    {
      id: '5',
      name: 'Business Class Hotel',
      location: 'Tokyo, Japan',
      rating: 4.3,
      price: 159,
      image: require('../assets/Materials/06-Explore Page/image-1.png'),
      description: 'Modern hotel perfect for business travelers in central Tokyo.'
    },
    {
      id: '6',
      name: 'Historic Grand Hotel',
      location: 'Paris, France',
      rating: 4.6,
      price: 279,
      image: require('../assets/Materials/06-Explore Page/Rectangle 785.png'),
      description: 'Elegant historic hotel near major Parisian attractions.'
    }
  ];

  useEffect(() => {
    setHotels(sampleHotels);
    setFilteredHotels(sampleHotels);
  }, []);

  useEffect(() => {
    filterAndSortHotels();
  }, [searchQuery, sortBy, hotels]);

  const filterAndSortHotels = () => {
    let filtered = hotels;

    if (searchQuery) {
      filtered = filtered.filter(hotel =>
        hotel.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        hotel.location.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    filtered = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return a.price - b.price;
        case 'price-high':
          return b.price - a.price;
        case 'rating':
          return b.rating - a.rating;
        default:
          return a.name.localeCompare(b.name);
      }
    });

    setFilteredHotels(filtered);
  };

  const handleHotelPress = (hotel) => {
    navigation.navigate('HotelDetails', { hotel });
  };

  const renderHotelCard = ({ item }) => (
    <TouchableOpacity
      style={styles.hotelCard}
      onPress={() => handleHotelPress(item)}
    >
      <Image source={{ uri: item.image }} style={styles.hotelImage} />
      <View style={styles.hotelInfo}>
        <Text style={styles.hotelName}>{item.name}</Text>
        <Text style={styles.hotelLocation}>{item.location}</Text>
        <View style={styles.ratingContainer}>
          <Text style={styles.rating}>⭐ {item.rating}</Text>
          <Text style={styles.price}>R{item.price}/night</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Find Your Perfect Stay</Text>
      
      
      <TextInput
        style={styles.searchInput}
        placeholder="Search hotels or locations..."
        value={searchQuery}
        onChangeText={setSearchQuery}
      />


      <View style={styles.sortContainer}>
        <Text style={styles.sortLabel}>Sort by:</Text>
        <TouchableOpacity
          style={[styles.sortButton, sortBy === 'name' && styles.sortButtonActive]}
          onPress={() => setSortBy('name')}
        >
          <Text style={[styles.sortText, sortBy === 'name' && styles.sortTextActive]}>
            Name
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.sortButton, sortBy === 'price-low' && styles.sortButtonActive]}
          onPress={() => setSortBy('price-low')}
        >
          <Text style={[styles.sortText, sortBy === 'price-low' && styles.sortTextActive]}>
            Price Low
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.sortButton, sortBy === 'price-high' && styles.sortButtonActive]}
          onPress={() => setSortBy('price-high')}
        >
          <Text style={[styles.sortText, sortBy === 'price-high' && styles.sortTextActive]}>
            Price High
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.sortButton, sortBy === 'rating' && styles.sortButtonActive]}
          onPress={() => setSortBy('rating')}
        >
          <Text style={[styles.sortText, sortBy === 'rating' && styles.sortTextActive]}>
            Rating
          </Text>
        </TouchableOpacity>
      </View>

      
      <FlatList
        data={filteredHotels}
        renderItem={renderHotelCard}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContainer}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
  },
  searchInput: {
    backgroundColor: '#f8f8f8',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e8e8e8',
    fontSize: 16,
  },
  sortContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    flexWrap: 'wrap',
  },
  sortLabel: {
    marginRight: 12,
    color: '#666',
    fontSize: 14,
  },
  sortButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: '#f0f0f0',
    marginRight: 8,
    marginBottom: 8,
  },
  sortButtonActive: {
    backgroundColor: '#FF385C',
  },
  sortText: {
    fontSize: 12,
    color: '#666',
  },
  sortTextActive: {
    color: '#fff',
    fontWeight: 'bold',
  },
  listContainer: {
    paddingBottom: 20,
  },
  hotelCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  hotelImage: {
    width: '100%',
    height: 200,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  hotelInfo: {
    padding: 16,
  },
  hotelName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
    color: '#333',
  },
  hotelLocation: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  rating: {
    fontSize: 14,
    color: '#666',
  },
  price: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FF385C',
  },
});

export default ExploreScreen;