import {useState, useEffect} from React;

export default function ProductDetails() {
    const {product, setProduct} = useState(null);

    useEffect(() =>{
        fetch("https://fakestoreapi.com/products/")
        .then (res= res.json())
        .then (data => setProduct (data))
        .catch(err => console.error('error fetching data'), err)

    }, [id])

    if (!product) return <p> product loading</p>

    return(
        <div>
            <img src={product.image} alt={product.title} />
            <h2> product.title</h2>
            <p> product.description</p>
            <h3>R{product.price}</h3>
            <p> Category: {product.category}</p>

        </div>
    )




}