import {useState, useEffect} from react;
import Product_card from './Product_card'

export default function ProductCard(product, onSelect) {
  const [Products, setProducts] = usestate([])


  return(
    <div onClick={(product)}>
        <img src = {product.image} alt ={product.title}/>
        <h3>product.title</h3>
        <p>R{product.price}</p>
    </div>



    
      /*{products.map(product => (
        <ProductCard key = {product.id} product = {product}>
      )});
    */
      );
    };
      