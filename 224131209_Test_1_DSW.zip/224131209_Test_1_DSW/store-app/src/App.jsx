import React, { useEffect, useState } from "react";
import ProductList from "./ProductList";
import ProductDetail from "./ProductDetail";


export default function App() {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);

  
  useEffect(() => {
    fetch("https://fakestoreapi.com/products")
      .then(res => res.json())
      .then(data => setProducts(data))
      .catch(err => console.error(" error fetching products ", err));
  }, []);

  if (selectedProduct) {
    return (
      <ProductDetail
        product={selectedProduct}
        onBack={() => setSelectedProduct(null)}
      />
    );
  }

  return (
    <ProductList products={products} onSelect={setSelectedProduct} />
  );
}
