import React, { useEffect, useState } from "react";
import { View, Text, FlatList, Image, TouchableOpacity, StyleSheet } from "react-native";

export default function HomeScreen({ navigation }) {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch("https://fakestoreapi.com/products")
      .then(res => res.json())
      .then(data => setProducts(data));
  }, []);

  return (
    <FlatList
      data={products}
      keyExtractor={ (item) => item.id.toString()}
      renderItem={({ item }) => (
        <TouchableOpacity
          onPress={() => navigation.navigate("Details ", { id: item.id })}
        >
          <Image source={{ uri: item.image }} style={styles.img} />
          <Text>{item.title}</Text>
        </TouchableOpacity>
      )}
    />
  );
}

