import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyBwHkNeiUXU-Hn5wBFr-MJfMHnIrq-p0Hs",
  authDomain: "shopez-4fc84.firebaseapp.com",
  projectId: "shopez-4fc84",
  storageBucket: "shopez-4fc84.firebasestorage.app",
  messagingSenderId: "179772862755",
  appId: "1:179772862755:web:163d94ffbbdfd3f34e5c96"
};


const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);

export const database = getDatabase(app);

export default app;