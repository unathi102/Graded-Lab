import React from "react";
import { View, Text, Image, Button, StyleSheet, Alert } from "react-native";
import { auth, db } from "../firebaseConfig";
import { ref, set, get, child } from "firebase/database";

export default function ProductDetail({ route }) {
  const { product } = route.params;

  const addToCart = async () => {
    const userId = auth.currentUser?.uid;
    if (!userId) return Alert.alert("Error", "Not logged in");

    const cartRef = ref(db, `carts/${userId}/${product.id}`);
    try {
      const snapshot = await get(child(ref(db), `carts/${userId}/${product.id}`));
      let qty = snapshot.exists() ? snapshot.val().quantity + 1 : 1;

      await set(cartRef, {
        id: product.id,
        title: product.title,
        price: product.price,
        image: product.image,
        quantity: qty,
      });

      Alert.alert("Added", `R{product.title} added to your cart.`);
    } catch (error) {
      Alert.alert("Error", error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Image source={{ uri: product.image }} style={styles.image} />
      <Text style={styles.title}>{product.title}</Text>
      <Text style={styles.price}>R{product.price}</Text>
      <Text style={styles.desc}>{product.description}</Text>
      <Button title="Add to Cart" onPress={addToCart} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 10 },
  image: { width: "100%", height: 300, resizeMode: "contain" },
  title: { fontSize: 20, fontWeight: "bold", marginVertical: 10 },
  price: { fontSize: 18, color: "green", marginBottom: 10 },
  desc: { marginBottom: 20, color: "#333" },
});
