import React, { useEffect, useState } from "react";
import { View, Text, Image, FlatList, Button, StyleSheet, Alert, ActivityIndicator, TouchableOpacity 
} from "react-native";
import { auth, db } from "../firebaseConfig";
import { ref, onValue, set, remove } from "firebase/database";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function CartScreen({ navigation }) {
  const [cart, setCart] = useState({});
  const [userId, setUserId] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      console.log("No logged-in user found");
      Alert.alert("Error", "please log in to view your cart");
      navigation.navigate("Login");
      return;
    }

    setUserId(currentUser.uid);
  }, []);

  useEffect(() => {
    if (!userId) return;

    const cartRef = ref(db, `carts/${userId}`);

    AsyncStorage.getItem("cart")
      .then((stored) => {
        if (stored) {
          setCart(JSON.parse(stored));
        }
      })
      .catch(error => {
        console.log("error loading from local storage:", error);
      });


    const unsubscribe = onValue(cartRef, async (snapshot) => {
      try {
        const data = snapshot.val() || {};
        console.log("cart data from Firebase:", data);
        setCart(data);
        await AsyncStorage.setItem("cart", JSON.stringify(data));
      } catch (error) {
        console.log("error updating cart:", error);
      } finally {
        setLoading(false);
      }
    }, (error) => {
      console.log("Firebase error:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [userId]);

  const increaseQty = (id) => {
    if (!userId) return;
    
    const item = cart[id];
    if (!item) return;
    
    set(ref(db, `carts/${userId}/${id}`), {
      ...item,
      quantity: (item.quantity || 0) + 1,
    }).catch(error => {
      Alert.alert("Error", "Failed to update quantity");
      console.log("Error increasing quantity:", error);
    });
  };

  const decreaseQty = (id) => {
    if (!userId) return;
    
    const item = cart[id];
    if (!item) return;
    
    const newQuantity = (item.quantity || 0) - 1;
    
    if (newQuantity > 0) {
      set(ref(db, `carts/${userId}/${id}`), {
        ...item,
        quantity: newQuantity,
      }).catch(error => {
        Alert.alert("Error", "Failed to update quantity");
        console.log("Error decreasing quantity:", error);
      });
    } else {
      remove(ref(db, `carts/${userId}/${id}`)).catch(error => {
        Alert.alert("Error", "Failed to remove item");
        console.log("Error removing item:", error);
      });
    }
  };

  const removeItem = (id) => {
    if (!userId) return;
    
    Alert.alert(
      "Remove Item",
      "Are you sure you want to remove this item from your cart?",
      [
        { text: "Cancel", style: "cancel" },
        { 
          text: "Remove", 
          style: "destructive",
          onPress: () => {
            remove(ref(db, `carts/${userId}/${id}`)).catch(error => {
              Alert.alert("Error", "Failed to remove item");
              console.log("Error removing item:", error);
            });
          }
        }
      ]
    );
  };

  const total = Object.values(cart).reduce(
    (sum, item) => sum + (item.price || 0) * (item.quantity || 0),
    0
  );

  const cartItems = Object.values(cart);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text>Loading cart...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Your Cart</Text>

      {cartItems.length === 0 ? (
        <View style={styles.emptyCart}>
          <Text style={styles.emptyText}>No items in your cart.</Text>
          <Button 
            title="Continue Shopping" 
            onPress={() => navigation.navigate("Products")} 
          />
        </View>
      ) : (
        <>
          <FlatList
            data={cartItems}
            keyExtractor={(item) => item.id ? item.id.toString() : Math.random().toString()}
            renderItem={({ item }) => (
              <View style={styles.item}>
                <Image source={{ uri: item.image }} style={styles.image} />
                <View style={styles.itemDetails}>
                  <Text style={styles.name} numberOfLines={2}>{item.title}</Text>
                  <Text style={styles.price}>
                    R{(item.price || 0).toFixed(2)} x {item.quantity || 0}
                  </Text>
                  <Text style={styles.subtotal}>
                    Subtotal: R{((item.price || 0) * (item.quantity || 0)).toFixed(2)}
                  </Text>
                  <View style={styles.buttons}>
                    <TouchableOpacity 
                      style={styles.qtyButton} 
                      onPress={() => decreaseQty(item.id)}
                    >
                      <Text style={styles.qtyButtonText}>-</Text>
                    </TouchableOpacity>
                    <Text style={styles.quantity}>{item.quantity || 0}</Text>
                    <TouchableOpacity 
                      style={styles.qtyButton} 
                      onPress={() => increaseQty(item.id)}
                    >
                      <Text style={styles.qtyButtonText}>+</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={styles.removeButton} 
                      onPress={() => removeItem(item.id)}
                    >
                      <Text style={styles.removeButtonText}>Remove</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            )}
          />
          <View style={styles.footer}>
            <Text style={styles.total}>Total: R{total.toFixed(2)}</Text>
          </View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    padding: 10,
    backgroundColor: '#f5f5f5'
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  title: { 
    fontSize: 24, 
    fontWeight: "bold", 
    marginBottom: 20,
    textAlign: 'center'
  },
  emptyCart: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  emptyText: {
    fontSize: 18,
    marginBottom: 20,
    color: '#666'
  },
  item: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    marginBottom: 10,
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  image: { 
    width: 80, 
    height: 80, 
    marginRight: 15,
    borderRadius: 8
  },
  itemDetails: {
    flex: 1
  },
  name: { 
    fontSize: 16, 
    fontWeight: "500",
    marginBottom: 5
  },
  price: { 
    color: "green", 
    fontWeight: 'bold',
    marginBottom: 2
  },
  subtotal: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8
  },
  buttons: { 
    flexDirection: "row", 
    alignItems: 'center',
    gap: 10
  },
  qtyButton: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#007AFF',
    justifyContent: 'center',
    alignItems: 'center'
  },
  qtyButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold'
  },
  quantity: {
    fontSize: 16,
    fontWeight: 'bold',
    minWidth: 20,
    textAlign: 'center'
  },
  removeButton: {
    backgroundColor: '#FF3B30',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 5,
    marginLeft: 'auto'
  },
  removeButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold'
  },
  footer: {
    backgroundColor: 'white',
    padding: 15,
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    marginTop: 10
  },
  total: { 
    fontSize: 20, 
    fontWeight: "bold", 
    marginBottom: 15, 
    textAlign: "center",
    color: '#007AFF'
  },
});