import React, { useState } from "react";
import { View, Text, TextInput, Button, Alert, StyleSheet } from "react-native";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebaseConfig";

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    if (!email || !password) {
      Alert.alert("Error", "Please enter email and password");
      return;
    }
    signInWithEmailAndPassword(auth, email, password)
      .then(() => Alert.alert("Success", "Logged in"))
      .catch((error) => Alert.alert("Login Failed", error.message));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>ShopEZ Login</Text>
      <TextInput style={styles.input} 
      placeholder="Email" 
      value={email} 
      onChangeText={setEmail} />
      
      <TextInput style={styles.input} 
      placeholder="Password" 
      value={password} secureTextEntry 
      onChangeText={setPassword} />
      <Button title="Login" onPress={handleLogin} />
      <Text style={styles.link} onPress={() => navigation.navigate("Register")}>
        Don't have an account? Register
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", padding: 20 },
  title: { fontSize: 24, fontWeight: "bold", textAlign: "center", marginBottom: 20 },
  input: { borderWidth: 1, borderColor: "#ccc", padding: 10, marginBottom: 10, borderRadius: 8 },
  link: { color: "blue", textAlign: "center", marginTop: 10 },
});
